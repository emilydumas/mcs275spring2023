This is the MCS 275 Spring 2023 Project 1 starter pack version 1.0.
By David Dumas.

